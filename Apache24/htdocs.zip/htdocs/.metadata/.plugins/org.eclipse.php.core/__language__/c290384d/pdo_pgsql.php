<?php

// Start of pdo_pgsql v.7.1.1
// End of pdo_pgsql v.7.1.1
