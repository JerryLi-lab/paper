<?php
    session_start();
    if (!array_key_exists("account",$_SESSION))
    {
        echo "<script> window.location.href ='login.php'; </script>";
        return;
    } 
?>