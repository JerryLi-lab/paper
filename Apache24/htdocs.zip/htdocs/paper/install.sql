/*
MySQL Data Transfer
Source Host: localhost
Source Database: mydb
Target Host: localhost
Target Database: mydb
Date: 2011/6/3 13:59:12
*/

-- SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL auto_increment,
  `account` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `firstname` varchar(50) default NULL,
  `lastname` varchar(50) default NULL,
  `phone` varchar(200) default NULL,
  `email` varchar(200) default NULL,
  `position` int(11) NOT NULL,
  `department` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records 
-- ----------------------------
/*INSERT INTO `users` VALUES ('3', "22", "22", 'fname1', 'lname1', '(000)000-0000', 'name1@gmail.com', '0', '0');
INSERT INTO `users` VALUES ('4', "33", "33", 'fname2', 'lname2', '(000)000-0000', 'name2@gmail.com', '0', '0');
INSERT INTO `users` VALUES ('5', "44", "44", 'fname3', 'lname3', '(000)000-0000', 'name3@gmail.com', '0', '0');
INSERT INTO `users` VALUES ('7', "44", "44", 'fname4', 'lname4', '(000)000-0000', 'name4@gmail.com', '0', '0');
INSERT INTO `users` VALUES ('8', "22", "22", 'fname5', 'lname5', '(000)000-0000', 'name5@gmail.com', '0', '0');
INSERT INTO `users` VALUES ('9', "22", "22", 'fname6', 'lname6', '(000)000-0000', 'name6@gmail.com', '0', '0');
INSERT INTO `users` VALUES ('10', "22", "22", 'fname7', 'lname7', '(000)000-0000', 'name7@gmail.com', '0', '0');
INSERT INTO `users` VALUES ('11', "22", "22", 'fname8', 'lname8', '(000)000-0000', 'name8@gmail.com', '0', '0');
INSERT INTO `users` VALUES ('12', "22", "22", 'fname9', 'lname9', '(000)000-0000', 'name9@gmail.com', '0', '0');
INSERT INTO `users` VALUES ('13', "22", "22", 'fname10', 'lname10', '(000)000-0000', 'name10@gmail.com', '0', '0');*/

DROP TABLE IF EXISTS `attendance`;
CREATE TABLE `attendance` (
  `user_id` int(11) NOT NULL,
  `date_time` datetime default NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
